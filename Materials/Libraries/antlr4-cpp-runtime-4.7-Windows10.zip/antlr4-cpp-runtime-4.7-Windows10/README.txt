# The C++ version of ANTLR 4 on Windows 10

**The reason the C++ Windows runtime library as downloaded from the ANTLR website doesn't work is that the library is built for Microsoft Visual Studio.**

I successfully built a non-MSVS version of the library for Windows 10 from the source files. It works for Pcl2Cpp. I've uploaded a zip file containing ANTLR 4's compile-time .h header files and the runtime library for Windows 10 to: http://www.cs.sjsu.edu/~mak/CMPE152/code/antlr4-cpp-runtime-
4.7-Windows10.zip

When you run the C++ version of a generated compiler in Windows 10, it wants to use
the cygantlr4-runtime-4.7.dll dynamically-linked library in the lib directory. Therefore, you must
first put the lib directory in your execution path. Make sure it's there by running the 'path' command. You may have to restart Windows.

If you don't know how to do the above, a alternative strategy is to copy the library to the same directory as your compiler executable.

You must have the lib directory on your execution path in order to run the compiler inside of Eclipse
(or you can copy the library into your project).

Note that the runtime library is different from the compile-time library antlr4-runtime. You still must set up the -l and -L options as before.
