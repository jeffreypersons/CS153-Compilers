# Assignment \# 3: When Statement

### compile all the files and generate an executable file
    make

### remove all generated object code and build related files

    make clean

### test when statement compilation and execution *_without_* errors
    ./Chapter8cpp compile -ix when.txt > when_compiled.txt

    ./Chapter8cpp execute when.txt > when_executed.txt

    printf '%b\n' "$(cat when_compiled.txt)"

    printf '%b\n' "$(cat when_executed.txt)"


### test when statement compilation and execution *_with_* errors
    ./Chapter8cpp compile -ix whenerrors.txt > whenerrors_compiled.txt

    ./Chapter8cpp execute whenerrors.txt > whenerrors_executed.txt

    printf '%b\n' "$(cat whenerrors_compiled.txt)"

    printf '%b\n' "$(cat whenerrors_executed.txt)"
